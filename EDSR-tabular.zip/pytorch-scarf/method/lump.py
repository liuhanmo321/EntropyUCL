from utils.buffer import Buffer

from torch.nn import functional as F
from .continual_model import ContinualModel
import random

import numpy as np
import torch
from tqdm.auto import tqdm

class LUMP(ContinualModel):
    NAME = 'lump'
    COMPATIBILITY = ['class-il', 'domain-il', 'task-il', 'general-continual']

    def __init__(self, args, model, criterion, device):
        super(LUMP, self).__init__(args, model, criterion, device)
        self.buffer = Buffer(self.args.model.buffer_size, self.device)

    def train_epoch(self, train_loader, dataset_idx, epoch):
        
        self.model.train()
        epoch_loss = 0.0
        batch = tqdm(train_loader, desc=f"Epoch {epoch}", leave=False)

        for anchor, positive, _ in batch:
            anchor, positive = anchor.to(self.device), positive.to(self.device)

            # reset gradients
            self.opt.zero_grad()

            self.model.to(self.device)
            # get embeddings

            if self.buffer.is_empty():
                emb_anchor, emb_positive, pred_emb_anchor, pred_emb_positive = self.model(anchor, positive, dataset_idx)
                loss = (self.criterion(pred_emb_anchor, emb_positive) + self.criterion(pred_emb_positive, emb_anchor)) / 2
            else:
                
            
                emb_anchor, emb_positive, pred_emb_anchor, pred_emb_positive = self.model(anchor, positive, dataset_idx)

            # compute loss
            loss = (self.criterion(pred_emb_anchor, emb_positive) + self.criterion(pred_emb_positive, emb_anchor)) / 2
            loss.backward()

            # update model weights
            self.opt.step()

            # log progress
            epoch_loss += anchor.size(0) * loss.item()
            batch.set_postfix({"loss": loss.item()})

        return epoch_loss / len(train_loader.dataset)

    def observe(self, inputs1, labels, inputs2, notaug_inputs):

        self.opt.zero_grad()
        if self.buffer.is_empty():
            data_dict = self.net.forward(inputs1.to(self.device, non_blocking=True), inputs2.to(self.device, non_blocking=True))
            loss = data_dict['loss'].mean()
            data_dict['loss'] = data_dict['loss'].mean()
        else:
            buf_inputs, buf_inputs1 = self.buffer.get_data(
                self.args.train.batch_size, transform=self.transform)
            lam = np.random.beta(self.args.train.alpha, self.args.train.alpha)
            mixed_x = lam * inputs1.to(self.device) + (1 - lam) * buf_inputs[:inputs1.shape[0]].to(self.device)
            mixed_x_aug = lam * inputs2.to(self.device) + (1 - lam) * buf_inputs1[:inputs1.shape[0]].to(self.device)
            data_dict = self.net.forward(mixed_x.to(self.device, non_blocking=True), mixed_x_aug.to(self.device, non_blocking=True))
            loss = data_dict['loss'].mean()
            data_dict['loss'] = data_dict['loss'].mean()
            data_dict['penalty'] = 0.0
        
        loss.backward()
        self.opt.step()
        data_dict.update({'lr': self.args.train.base_lr})
        if self.args.cl_default:
            self.buffer.add_data(examples=notaug_inputs, logits=labels)
        else:
            self.buffer.add_data(examples=notaug_inputs, logits=inputs2)

        return data_dict
