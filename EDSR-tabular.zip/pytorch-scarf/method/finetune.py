from torch.nn import functional as F
from .continual_model import ContinualModel
import random

import numpy as np
import torch
from tqdm.auto import tqdm

class Finetune(ContinualModel):
    NAME = 'finetune'
    COMPATIBILITY = ['class-il', 'domain-il', 'task-il', 'general-continual']

    def __init__(self, args, model, criterion, device):
        super(Finetune, self).__init__(args, model, criterion, device)

    def train_epoch(self, train_loader, dataset_idx, epoch):
        
        self.model.train()
        epoch_loss = 0.0
        batch = tqdm(train_loader, desc=f"Epoch {epoch}", leave=False)

        for anchor, positive, _ in batch:
            anchor, positive = anchor.to(self.device), positive.to(self.device)

            # reset gradients
            self.opt.zero_grad()
            
            self.model.to(self.device)
            # get embeddings
            emb_anchor, emb_positive, pred_emb_anchor, pred_emb_positive = self.model(anchor, positive, dataset_idx)

            # compute loss
            loss = (self.criterion(pred_emb_anchor, emb_positive) + self.criterion(pred_emb_positive, emb_anchor)) / 2
            loss.backward()

            # update model weights
            self.opt.step()

            # log progress
            epoch_loss += anchor.size(0) * loss.item()
            batch.set_postfix({"loss": loss.item()})

        return epoch_loss / len(train_loader.dataset)
