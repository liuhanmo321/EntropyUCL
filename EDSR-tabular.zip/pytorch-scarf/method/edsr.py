from torch.nn import functional as F
from .continual_model import ContinualModel
import random
from copy import deepcopy
import numpy as np
import torch
from tqdm.auto import tqdm

from .utils import MLP

import pandas as pd
from sklearn.metrics import pairwise_distances_argmin, pairwise_distances
from sklearn.neighbors import NearestNeighbors
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.decomposition import PCA

from torch.utils.data import DataLoader
import math
import copy

def D(p, z, noise=None, T=None, version='simplified', type='simsiam'): # negative cosine similarity
    if type == 'simsiam':
        if noise == None:
            if T != None:
                p = torch.pow(p, T)
                z = torch.pow(z, T)
            return - F.cosine_similarity(p, z.detach(), dim=-1).mean()
        else:
            z = z.detach()
            noise = noise.reshape(-1, 1).expand(-1, p.shape[1]).to(p.device) * torch.randn(p.shape).to(p.device)
            z_noise = F.normalize(z, dim=1) + noise
            if T != None:
                p = torch.pow(p, T)
                z_noise = torch.pow(z_noise, T)
            return - F.cosine_similarity(p, z_noise, dim=-1).mean()
    else:
        p_norm = (p - p.mean(0)) / p.std(0) # NxD
        if noise == None:
            z_norm = (z - z.mean(0)) / z.std(0) # NxD
        else:
            # z = z.detach()
            z_mag = torch.norm(z, dim=1)
            noise = (noise.to(p.device) * z_mag).reshape(-1, 1).expand(-1, 2048) * torch.randn(p.shape).to(p.device)
            z_noise = z + noise
            z_norm = (z_noise - z_noise.mean(0)) / z_noise.std(0)

        N = p_norm.size(0)
        D = p_norm.size(1)

        # cross-correlation matrix
        c = torch.mm(p_norm.T, z_norm) / N # DxD
        # loss
        c_diff = (c - torch.eye(D,device=p_norm.device)).pow(2) # DxD
        # multiply off-diagonal elems of c_diff by lambda
        c_diff[~torch.eye(D, dtype=bool)] *= 5e-3
        loss = c_diff.sum()

        return loss

class EDSR(ContinualModel):
    NAME = 'edsr'
    COMPATIBILITY = ['class-il', 'domain-il', 'task-il', 'general-continual']

    def __init__(self, args, model, criterion, device):
        super(EDSR, self).__init__(args, model, criterion, device)

        self.old_model = None
        self.distill_head = MLP(self.args.emb_dim, self.args.emb_dim, 2, dropout=args.dropout)
        self.distill_opt = torch.optim.Adam(self.distill_head.parameters(), lr=args.lr)

        self.buffer = Buffer(self.args.buffer_size, self.device)
        self.seen_tasks = 0

        self.coreset = []

    def train_epoch(self, train_loader, dataset_idx, epoch):
        
        self.model.train()
        epoch_loss = 0.0
        batch = tqdm(train_loader, desc=f"Epoch {epoch}", leave=False)

        for anchor, positive, _ in batch:
            anchor, positive = anchor.to(self.device), positive.to(self.device)

            # reset gradients
            self.opt.zero_grad()
            self.distill_opt.zero_grad()
            
            self.model.to(self.device)

            if self.old_model is not None:
                self.old_model.to(self.device)
                # self.distill_head.to(self.device)
                # print(dataset_idx)
                emb_anchor, emb_positive, pred_emb_anchor, pred_emb_positive, old_emb_anchor, old_emb_positive = self.model(anchor, positive, dataset_idx, old_model=self.old_model)
                loss = (self.criterion(pred_emb_anchor, emb_positive) + self.criterion(pred_emb_positive, emb_anchor)) / 2
                
                dist_emb_anchor, dist_emb_positive = self.distill_head(emb_anchor), self.distill_head(emb_positive)
                
                distill_loss = (self.criterion(self.model.prediction_head(dist_emb_anchor), old_emb_anchor) \
                                + self.criterion(self.model.prediction_head(dist_emb_positive), old_emb_positive)) / 2
                
                old_anchor, noise, old_dataset_idx_list = self.buffer.get_data(self.args.batch_size)

                replay_loss = 0
                num_old_dataset = len(np.unique(old_dataset_idx_list))
                for old_dataset_idx in range(num_old_dataset):
                    mask = old_dataset_idx_list == old_dataset_idx
                    curr_old_anchor = torch.tensor([old_anchor[i] for i, m in enumerate(mask) if m])
                    rand_idx = np.random.permutation(len(curr_old_anchor))
                    old_positive = self.model.get_corrupted_data(curr_old_anchor, curr_old_anchor[rand_idx])
                    old_positive = old_positive.to(self.device)

                    length = len(old_positive)
                    emb_old_positive = self.model.get_representations(old_positive, old_dataset_idx)
                    with torch.no_grad():
                        old_emb_old_positive = self.old_model.get_representations(old_positive, old_dataset_idx)

                    replay_loss += D(self.model.prediction_head(self.distill_head(emb_old_positive)), old_emb_old_positive, noise=noise[mask]) * length / len(old_positive)

                loss = loss + distill_loss + replay_loss
            else:
                emb_anchor, emb_positive, pred_emb_anchor, pred_emb_positive = self.model(anchor, positive, dataset_idx)
                loss = (self.criterion(pred_emb_anchor, emb_positive) + self.criterion(pred_emb_positive, emb_anchor)) / 2            

            loss.backward()
            # update model weights
            self.opt.step()
            self.distill_opt.zero_grad()

            # log progress
            epoch_loss += anchor.size(0) * loss.item()
            batch.set_postfix({"loss": loss.item()})

        return epoch_loss / len(train_loader.dataset)


    def end_dataset(self, dataloader):
        self.old_model = deepcopy(self.model.cpu()).to(self.device)

        extractor = torch.nn.Sequential(self.model.unifiers[self.seen_tasks], self.model.encoder)
        extractor.to(self.device)
        extractor.eval()

        feature_bank = []
        data_bank = []
        # aug_data_bank = []
        label_bank = []
        with torch.no_grad():
            # generate feature bank
            for idx, (anchor, positive, target) in enumerate(dataloader):
            # for data, target in tqdm(memory_data_loader, desc='Feature extracting', leave=False, disable=True):
                feature = extractor(anchor.to(self.device))
                
                feature_bank.append(feature.cpu())
                data_bank.append(anchor.cpu())
                label_bank += target
            # [D, N]
            feature_bank = torch.cat(feature_bank, dim=0).contiguous()
            data_bank = torch.cat(data_bank, dim=0).contiguous()
            label_bank = np.array(label_bank)

            feature_bank = F.normalize(feature_bank, dim=1)
            print(feature_bank.shape)

        if self.args.cluster_type == 'pca':
            temp_feature_bank = feature_bank.cpu().numpy()

            pca = PCA(n_components=min(self.args.buffer_size, temp_feature_bank.shape[1]))
            ort_vec = pca.fit_transform(temp_feature_bank.T).T
            print(ort_vec.shape)

            indices = pairwise_distances_argmin(ort_vec, temp_feature_bank)

            print("data selected")
            
            # if self.args.add_noise:
            std_list = []              
            neigh = NearestNeighbors(n_neighbors=self.args.knn_n)
            neigh.fit(temp_feature_bank)
            _, knn_indices = neigh.kneighbors(temp_feature_bank[indices, :], n_neighbors=self.args.knn_n)
            print(knn_indices.shape)
            for i in range(knn_indices.shape[0]):
                related_features = feature_bank[knn_indices[i], :]
                std = torch.std(related_features, dim=0)
                std_list.append(torch.mean(std))
                # print(std_list)
            # else:
            #     std_list = None

        print('noise stored: ', std_list != None)
        self.buffer.add_data(examples=data_bank[indices, :], logits=std_list, seen=self.seen_tasks)                

        saved_info = pd.Series(label_bank[indices]).value_counts()
        print(saved_info)

        print('number of examples: ', len(self.buffer.examples))
        print('buffer number: ', len(self.buffer.ds_buffer))
        print('selected num of data from current data: ', len(self.buffer.ds_buffer[-1]))

        self.seen_tasks += 1


def reservoir(num_seen_examples: int, buffer_size: int) -> int:
    """
    Reservoir sampling algorithm.
    :param num_seen_examples: the number of seen examples
    :param buffer_size: the maximum buffer size
    :return: the target index if the current image is sampled, else -1
    """
    if num_seen_examples < buffer_size:
        return num_seen_examples

    rand = np.random.randint(0, num_seen_examples + 1)
    if rand < buffer_size:
        return rand
    else:
        return -1


def ring(num_seen_examples: int, buffer_portion_size: int, task: int) -> int:
    return num_seen_examples % buffer_portion_size + task * buffer_portion_size


class Buffer:
    """
    The memory buffer of rehearsal method.
    """
    def __init__(self, buffer_size, device, n_tasks=None, mode='reservoir'):
        assert mode in ['ring', 'reservoir']
        self.buffer_size = buffer_size
        self.device = device
        self.num_seen_examples = 0
        self.functional_index = eval(mode)
        if mode == 'ring':
            assert n_tasks is not None
            self.task_number = n_tasks
            self.buffer_portion_size = buffer_size // n_tasks
        self.attributes = ['examples', 'labels', 'logits', 'task_labels']
        self.ds_buffer = []
        self.noise_buffer = []
        self.dataset_idx_buffer = []   
        self.examples = []

    def init_tensors(self, examples: torch.Tensor, labels: torch.Tensor,
                     logits: torch.Tensor, task_labels: torch.Tensor) -> None:
        """
        Initializes just the required tensors.
        :param examples: tensor containing the images
        :param labels: tensor containing the labels
        :param logits: tensor containing the outputs of the network
        :param task_labels: tensor containing the task labels
        """
        for attr_str in self.attributes:
            attr = eval(attr_str)
            if attr is not None and not hasattr(self, attr_str):
                typ = torch.int64 if attr_str.endswith('els') else torch.float32
                setattr(self, attr_str, torch.zeros((self.buffer_size,
                        *attr.shape[1:]), dtype=typ, device=self.device))



    def add_data(self, examples, labels=None, logits=None, task_labels=None, seen=0):
        """
        Adds the data to the memory buffer according to the reservoir strategy.
        :param examples: tensor containing the images
        :param labels: tensor containing the labels
        :param logits: tensor containing the outputs of the network
        :param task_labels: tensor containing the task labels
        :return:
        """
        if not hasattr(self, 'examples'):
            self.init_tensors(examples, labels, logits=None, task_labels=None)
        
        self.ds_buffer.append(examples)
        # self.examples = torch.cat(self.ds_buffer, dim=0)
        self.examples += examples.tolist()

        self.dataset_idx_buffer.append(torch.ones(examples.shape[0]) * seen)
        self.dataset_idx = torch.cat(self.dataset_idx_buffer, dim=0)

        if logits != None:
            self.noise_buffer.append(torch.Tensor(logits))
            self.noises = torch.cat(self.noise_buffer, dim=0)        
            print(self.noises.shape)


    def get_data(self, size: int):
        """
        Random samples a batch of size items.
        :param size: the number of requested items
        :param transform: the transformation to be applied (data augmentation)
        :return:
        """
        # if size > self.examples.shape[0]:
        #     size = self.examples.shape[0]
        
        if size > len(self.examples):
            size = len(self.examples)

        choice = np.random.choice(len(self.examples), size=size, replace=False)

        ret_tuple = ([self.examples[c] for c in choice], self.noises[choice], self.dataset_idx[choice],)

        return ret_tuple

    def is_empty(self) -> bool:
        """
        Returns true if the buffer is empty, false otherwise.
        """
        if self.num_seen_examples == 0:
            return True
        else:
            return False

    def empty(self) -> None:
        """
        Set all the tensors to None.
        """
        for attr_str in self.attributes:
            if hasattr(self, attr_str):
                delattr(self, attr_str)
        self.num_seen_examples = 0