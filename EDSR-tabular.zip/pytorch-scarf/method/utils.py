import torch
import torch.nn as nn
import torch.nn.functional as F
import torch
import torch.nn as nn
import torch.nn.functional as F 

def D(p, z, noise=None, T=None, reduce=True): # negative cosine similarity
    if noise == None:
        if reduce:
            return - F.cosine_similarity(p, z.detach(), dim=-1).mean()
        else:
            return - F.cosine_similarity(p, z.detach(), dim=-1)
    else:
        z = z.detach()
        noise = noise.reshape(-1, 1).expand(-1, 2048).to(p.device) * torch.randn(p.shape).to(p.device)
        z_noise = F.normalize(z, dim=1) + noise
        return - F.cosine_similarity(p, z_noise, dim=-1).mean()


class SimSiamLoss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, p, z, T=None, noise=None, reduce=True):
        return D(p, z, T=T, noise=None, reduce=True)
    


class MLP(torch.nn.Sequential):
    """Simple multi-layer perceptron with ReLu activation and optional dropout layer"""

    def __init__(self, input_dim, hidden_dim, n_layers, dropout=0.0):
        layers = []
        in_dim = input_dim
        for _ in range(n_layers - 1):
            layers.append(torch.nn.Linear(in_dim, hidden_dim))
            layers.append(nn.ReLU(inplace=True))
            layers.append(torch.nn.Dropout(dropout))
            in_dim = hidden_dim

        layers.append(torch.nn.Linear(in_dim, hidden_dim))

        super().__init__(*layers)