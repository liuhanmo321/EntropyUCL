# provide code for receiving and parsing command line arguments
# and for reading in the configuration file

import argparse
import configparser
import os
import sys


def parse_args():
    parser = argparse.ArgumentParser(description="Run SCARF on tabular data.")
    parser.add_argument(
        "--config", type=str, default="config.ini", help="Path to the config file."
    )
    parser.add_argument(
        "--seed", type=int, default=1234, help="Random seed for reproducibility."
    )
    parser.add_argument(
        "--split",
        type=float,
        default=0.2,
        help="Fraction of the data to use for testing.",
    )
    parser.add_argument(
        "--gpu",
        type=int,
        default=0,
        help="GPU to use for training. Set -1 to use CPU.",
    )
    parser.add_argument(
        "--method",
        type=str,
        default="multitask",
        help="Method to use for training. Choose between 'finetune', 'cassle', 'lump', 'cassle_uniform'.",
    )
    parser.add_argument(
        "--batch_size", type=int, default=512, help="Batch size for training."
    )
    parser.add_argument(
        "--buffer_size", type=int, default=40, help="Batch size for training."
    )
    parser.add_argument(
        "--knn_n", type=int, default=100, help="Neighbor number for noises."
    )
    parser.add_argument(
        "--epochs", type=int, default=1000, help="Number of epochs to train for."
    )
    parser.add_argument(
        "--device",
        type=str,
        default="0",
        help="Device to use for training.",
    )
    parser.add_argument(
        "--cluster_type",
        type=str,
        default="pca",
        help="Type of clustering algorithm to use.",
    )
    parser.add_argument(
        "--lr", type=float, default=0.001, help="Learning rate for training."
    )
    parser.add_argument(
        "--emb_dim", type=int, default=128, help="Dimension of the learned embeddings."
    )
    parser.add_argument(
        "--input_dim", type=int, default=128, help="Dimension of the input embeddings."
    )
    parser.add_argument(
        "--dropout", type=float, default=0.1, help="dropout rate"
    )
    parser.add_argument(
        "--corruption_rate",
        type=float,
        default=0.6,
        help="Fraction of features to corrupt.",
    )
    parser.add_argument(
        "--result_dir",
        type=str,
        default="./result",
        help="Directory to save results in.",
    )
    parser.add_argument(
        "--ckpt_dir",
        type=str,
        default="./ckpt",
        help="Directory to save models in.",
    )
    parser.add_argument(
        "--save_model",
        action="store_true",
        help="Whether to save the trained model.",
    )
    parser.add_argument(
        "--save_embeddings",
        action="store_true",
        help="Whether to save the learned embeddings.",
    )
    parser.add_argument(
        "--save_plots",
        action="store_true",
        help="Whether to save the plots of the training loss.",
    )
    parser.add_argument(
        "--save_config",
        action="store_true",
        help="Whether to save the configuration file.",
    )
    parser.add_argument(
        "--save_config_name",
        type=str,
        default="config.ini",
        help="Name of the saved configuration file.",
    )
    parser.add_argument(
        "--save_config_dir",
        type=str,
        default="results",
        help="Directory to save the configuration file in.",
    )
    parser.add_argument(
        "--comment",
        type=str,
        default="",
        help="comments to add to the name of the saved files.",
    )

    return parser.parse_args()