# %load_ext autoreload
# %autoreload 2

import sys
import os
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import torch
from sklearn import datasets
from sklearn.linear_model import LogisticRegression
from sklearn.manifold import TSNE
from sklearn.metrics import (ConfusionMatrixDisplay, classification_report,
                             confusion_matrix)
from torch.optim import Adam
from torch.utils.data import DataLoader

sys.path.append("../")

from utils.prepare_dataset import load_dataset_list
from utils.train import dataset_embeddings, fix_seed, train_epoch
from utils.prepare_continual_model import get_continual_model
from utils.evaluation import evaluate, evaluate_single_dataset

from config import parse_args
import time


def run(args, repeat):
    device = torch.device(f"cuda:{args.gpu}" if torch.cuda.is_available() else "cpu")
    args.seed = repeat
    result_recording_path = os.path.join(args.result_dir, f"{args.method}_{args.comment}_seed{args.seed}.txt")

    fix_seed(args.seed)

    train_ds_list, test_ds_list, raw_feat_dim_list = load_dataset_list(seed=args.seed, split=0.2)

    continual_model = get_continual_model(args, raw_feat_dim_list, device)

    # Model Training
    acc_matrix = np.zeros((len(train_ds_list), len(train_ds_list)))
    avg_acc, avg_frg = [], []
    start_time = time.time()

    if args.method != 'multitask':
        for dataset_idx, train_ds in enumerate(train_ds_list):
            train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True)
            loss_history = []

            continual_model.args.buffer_size = int(0.01 * len(train_ds))
            for epoch in range(1, args.epochs + 1):
                continual_model.to(device)
                continual_model.train()
                epoch_loss = continual_model.train_epoch(train_loader, dataset_idx, epoch)
                loss_history.append(epoch_loss)

            # Model evaluation
            train_loader_list = [DataLoader(train_ds_list[temp_idx], batch_size=args.batch_size, shuffle=False) for temp_idx in range(dataset_idx + 1)]
            test_loader_list = [DataLoader(test_ds_list[temp_idx], batch_size=args.batch_size, shuffle=False) for temp_idx in range(dataset_idx + 1)]
            accs = evaluate(continual_model, train_loader_list, test_loader_list, device)

            for i, acc in enumerate(accs):
                acc_matrix[i][dataset_idx] = acc
            avg_acc.append(np.mean(accs))

            frgs = [np.max(acc_matrix[i, :]) - acc_matrix[i][dataset_idx] for i in range(dataset_idx + 1)]
            avg_frg.append(np.mean(frgs))

            print("Avereage accuracy: ", avg_acc[-1], " Average forgetting: ", avg_frg[-1])

            model_path = os.path.join(args.ckpt_dir, f"{args.method}_seed{args.seed}_{dataset_idx}.pth")

            state_dict = continual_model.state_dict()
            torch.save(state_dict, model_path)
            print(f"Model of Task {dataset_idx} saved to {model_path}")   

            if hasattr(continual_model, 'end_dataset'):
                continual_model.end_dataset(train_loader)
    else:
        for epoch in range(1, args.epochs + 1):
            for dataset_idx, train_ds in enumerate(train_ds_list):
                train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True)
                loss_history = []

            # for epoch in range(1, args.epochs + 1):
                continual_model.to(device)
                continual_model.train()
                epoch_loss = continual_model.train_epoch(train_loader, dataset_idx, epoch)
                loss_history.append(epoch_loss)

        # Model evaluation
        train_loader_list = [DataLoader(train_ds_list[temp_idx], batch_size=args.batch_size, shuffle=False) for temp_idx in range(len(train_ds_list))]
        test_loader_list = [DataLoader(test_ds_list[temp_idx], batch_size=args.batch_size, shuffle=False) for temp_idx in range(len(test_ds_list))]
        accs = evaluate(continual_model, train_loader_list, test_loader_list, device)

        for i, acc in enumerate(accs):
            acc_matrix[i][-1] = acc
        avg_acc.append(np.mean(accs))

        frgs = [np.max(acc_matrix[i, :]) - acc_matrix[i][-1] for i in range(dataset_idx + 1)]
        avg_frg.append(np.mean(frgs))

        print("Avereage accuracy: ", avg_acc[-1], " Average forgetting: ", avg_frg[-1])

        model_path = os.path.join(args.ckpt_dir, f"{args.method}_{args.comment}_seed{args.seed}_{dataset_idx}.pth")

        state_dict = continual_model.state_dict()
        torch.save(state_dict, model_path)
        print(f"Model of Task {dataset_idx} saved to {model_path}")   


    end_time = time.time()
    total_time = end_time - start_time    

    with open(result_recording_path, 'a+') as f:
        avg_acc_str = np.array2string(np.array(avg_acc), precision=2, separator='\t', max_line_width=200)
        avg_acc_str = avg_acc_str.replace('[', '').replace(']', '')
        avg_frg_str = np.array2string(np.array(avg_frg), precision=2, separator='\t', max_line_width=200)
        avg_frg_str = avg_frg_str.replace('[', '').replace(']', '')
        matrix_str = np.array2string(acc_matrix, precision=2, separator='\t', max_line_width=200)
        matrix_str = matrix_str.replace('[', '').replace(']', '')
        f.write('\n{}\t{}'.format(args.method, avg_acc_str))
        f.write('\n{}\t{}'.format(args.method, avg_frg_str))
        f.write('\nAccuracy matrix:\n {}\n'.format(matrix_str))
        f.write('total time is: %d' % total_time)
        f.write("\n")
    
    return avg_acc[-1], avg_frg[-1]


if __name__ == "__main__":
    args = parse_args()

    avg_acc_list, avg_frg_list = [], []
    for i in range(10):
        avg_acc, avg_frg = run(args, i)

        avg_acc_list.append(avg_acc)
        avg_frg_list.append(avg_frg)
    
    result_recording_path = os.path.join(args.result_dir, f"{args.method}_final.txt")

    with open(result_recording_path, 'a+') as f:
        avg_acc_str = np.array2string(np.array(avg_acc_list), precision=2, separator='\t', max_line_width=200)
        avg_acc_str = avg_acc_str.replace('[', '').replace(']', '')
        avg_frg_str = np.array2string(np.array(avg_frg_list), precision=2, separator='\t', max_line_width=200)
        avg_frg_str = avg_frg_str.replace('[', '').replace(']', '')
        f.write('\n{}\t{}'.format(args.method, avg_acc_str))
        f.write('\n{}\t{}'.format(args.method, avg_frg_str))
        f.write('\nAverage accuracy: {:.2f}±{:.2f}\t Average forgetting: {:.2f}±{:.2f}'.format(np.mean(avg_acc_list), np.std(avg_acc_list), np.mean(avg_frg_list), np.std(avg_frg_list)))
        f.write("\n")

    