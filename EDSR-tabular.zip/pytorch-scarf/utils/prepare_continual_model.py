from method.utils import *
from method.finetune import Finetune
from method.cassle import CaSSLe
from method.edsr import EDSR
from method.multitask import Multitask

from scarf.model import *

def get_continual_model(args, raw_feat_dim_list, device):
    """
    Returns the continual model.
    :param args: the command line arguments
    :param model: the backbone model
    :return: the continual model
    """

    model = SCARF(
        input_dim=args.input_dim, 
        raw_feat_dim_list=raw_feat_dim_list,
        emb_dim=args.emb_dim,
        corruption_rate=args.corruption_rate,
    )

    criterion = SimSiamLoss()

    if args.method == 'finetune':
        return Finetune(args, model, criterion, device)
    elif args.method == 'cassle':
        return CaSSLe(args, model, criterion, device)
    elif args.method == 'multitask':
        return Multitask(args, model, criterion, device)
    elif args.method == 'edsr':
        return EDSR(args, model, criterion, device)
