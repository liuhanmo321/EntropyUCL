import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import numpy as np
from tqdm import tqdm
from datetime import datetime
from typing import Tuple
import time
from hyperopt import fmin, tpe, hp, STATUS_OK, Trials, partial
import matplotlib.pyplot as plt

from sklearn.metrics import pairwise_distances_argmin, pairwise_distances
from sklearn.neighbors import NearestNeighbors
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.decomposition import PCA

def evaluate(continual_model, train_loader_list, test_loader_list, device, classifier=None) -> Tuple[list, list]:
    """
    Evaluates the accuracy of the model for each past task.
    :param model: the model to be evaluated
    :param dataset: the continual dataset at hand
    :return: a tuple of lists, containing the class-il
             and task-il accuracy for each task
    """
    status = continual_model.training
    continual_model.eval()
    accs = []

    for k in range(len(train_loader_list)):
        
        acc, _ = evaluate_single_dataset(continual_model.model, train_loader_list[k], test_loader_list[k], device, k)
        
        accs.append(acc)

    continual_model.train(status)
    return accs




# code copied from https://colab.research.google.com/github/facebookresearch/moco/blob/colab-notebook/colab/moco_cifar10_demo.ipynb#scrollTo=RI1Y8bSImD7N
# test using a knn monitor
def evaluate_single_dataset(model, train_loader, test_loader, device, dataset_idx, k=20, t=0.1, hide_progress=False, get_etp=False, args=None):
    model.eval()
    classes = len(np.unique(train_loader.dataset.target))
    # classes = 100
    total_top1 = total_top1_mask = total_top5 = total_num = 0.0
    feature_bank = []
    with torch.no_grad():
        # generate feature bank
        for data, _, target in tqdm(train_loader, desc='Feature extracting', leave=False, disable=True):
            feature = model.get_embeddings(data.to(device), dataset_idx)
            feature = F.normalize(feature, dim=1)
            feature_bank.append(feature)
        # [D, N]
        feature_bank = torch.cat(feature_bank, dim=0).t().contiguous()

        # if get_etp:
        #     if args.train.cluster_type == 'pca':
        #         temp_feature_bank = feature_bank.cpu().numpy()

        #         pca = PCA(n_components=args.model.buffer_size)
        #         ort_vec = pca.fit_transform(temp_feature_bank.T).T

        #         indices = pairwise_distances_argmin(ort_vec, temp_feature_bank)            
        #         etp = feature_entropy(feature_bank[indices])
        #         total_etp = feature_entropy(feature_bank)

        # [N]
        # feature_labels = torch.tensor(train_loader.dataset.targets - np.amin(train_loader.dataset.targets), device=feature_bank.device)
        feature_labels = torch.tensor(train_loader.dataset.target, device=feature_bank.device)
        # loop test data to predict the label by weighted knn search
        test_bar = tqdm(test_loader, desc='kNN', disable=True)
        for data, _,  target in test_bar:
            # data, target = data.cuda(non_blocking=True), target.cuda(non_blocking=True)
            data, target = data.to(device), target.to(device)
            feature = model.get_embeddings(data, dataset_idx)
            feature = F.normalize(feature, dim=1)
            
            pred_scores = knn_predict(feature, feature_bank, feature_labels, classes, k, t)

            total_num += data.shape[0]
            _, preds = torch.max(pred_scores.data, 1)
            total_top1 += torch.sum(preds == target).item()

    if get_etp:
        return total_top1 / total_num * 100, total_top1_mask / total_num * 100
    else:
        return total_top1 / total_num * 100, total_top1_mask / total_num * 100
    

# knn monitor as in InstDisc https://arxiv.org/abs/1805.01978
# implementation follows http://github.com/zhirongw/lemniscate.pytorch and https://github.com/leftthomas/SimCLR
def knn_predict(feature, feature_bank, feature_labels, classes, knn_k, knn_t):
    # compute cos similarity between each feature vector and feature bank ---> [B, N]
    sim_matrix = torch.mm(feature, feature_bank)
    # [B, K]
    sim_weight, sim_indices = sim_matrix.topk(k=knn_k, dim=-1)
    # [B, K]
    sim_labels = torch.gather(feature_labels.expand(feature.size(0), -1), dim=-1, index=sim_indices)
    sim_weight = (sim_weight / knn_t).exp()

    # counts for each class
    one_hot_label = torch.zeros(feature.size(0) * knn_k, classes, device=sim_labels.device)
    # [B*K, C]
    one_hot_label = one_hot_label.scatter(dim=-1, index=sim_labels.view(-1, 1), value=1.0)
    # weighted score ---> [B, C]
    pred_scores = torch.sum(one_hot_label.view(feature.size(0), -1, classes) * sim_weight.unsqueeze(dim=-1), dim=1)

    return pred_scores