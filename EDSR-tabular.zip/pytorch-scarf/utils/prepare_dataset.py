import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split

import os

categorical_names = {
    'shoppers': ['OperatingSystems', 'Browser', 'Region', 'TrafficType', 'Weekend'],
    'blast_char': ['SeniorCitizen']
    }

class TabularDataset(Dataset):
    def __init__(self, data, target, columns=None):
        self.data = np.array(data)
        self.target = np.array(target)
        self.columns = columns

    def __getitem__(self, indedata):
        # the dataset must return a pair of samples: the anchor and a random one from the
        # dataset that will be used to corrupt the anchor
        random_iddata = np.random.randint(0, len(self))
        random_sample = torch.tensor(self.data[random_iddata], dtype=torch.float)
        sample = torch.tensor(self.data[indedata], dtype=torch.float)
        target = self.target[indedata]

        return sample, random_sample, target

    def __len__(self):
        return len(self.data)

    def to_dataframe(self):
        return pd.DataFrame(self.data, columns=self.columns)

    @property
    def shape(self):
        return self.data.shape


def load_single_dataset(data_path, label_path, seed, split, data_name):
    data = pd.read_csv(data_path)
    target = pd.read_csv(label_path)

    # preprocess
    constant_cols = [c for c in data.columns if data[c].nunique() == 1]
    data.drop(columns=constant_cols, inplace=True)

    categorical_indicator = [False] * len(data.columns)
    for i, col in enumerate(data.columns):
        if data[col].dtypes == 'object':
            categorical_indicator[i] = True
        if data_name in categorical_names.keys() and col in categorical_names[data_name]:
            categorical_indicator[i] = True
        if set([0, 1]) == set(data[col].unique()):
            categorical_indicator[i] = True

    categorical_columns = data.columns[list(np.where(np.array(categorical_indicator)==True)[0])].tolist()
    cont_columns = list(set(data.columns.tolist()) - set(categorical_columns))

    for col in categorical_columns:
        data[col] = data[col].astype("object")
        data[col] = data[col].fillna(f"MissingValue")
        dummy = pd.get_dummies(data[col], prefix=col)
        data = pd.concat([data, dummy], axis=1).drop([col], axis=1)

    for col in cont_columns:
        data[col] = data[col].astype("float")
        data[col] = data[col].fillna(data[col].mean())
    
    target = target.values
    l_enc = LabelEncoder() 
    target = l_enc.fit_transform(target)

    train_data, test_data, train_target, test_target = train_test_split(
        data, 
        target.flatten(), 
        test_size=split, 
        stratify=target, 
        random_state=seed
    )

    train_data = pd.DataFrame(train_data, columns=data.columns)
    test_data = pd.DataFrame(test_data, columns=data.columns)
    scaler = StandardScaler()
    train_data[cont_columns] = scaler.fit_transform(train_data[cont_columns])
    test_data[cont_columns] = scaler.transform(test_data[cont_columns])
    # for col in cont_columns:
    #     train_data[col] = scaler.fit_transform(train_data[col])
    #     test_data[col] = scaler.transform(test_data[col])


    # to torch dataset
    train_ds = TabularDataset(
        train_data.to_numpy(), 
        train_target, 
    )
    test_ds = TabularDataset(
        test_data.to_numpy(), 
        test_target, 
    )

    print(f"Train set: {train_ds.shape}")
    print(f"Test set: {test_ds.shape}")

    return train_ds, test_ds

def load_dataset_list(seed, split):

    train_ds_list = []
    test_ds_list = []
    raw_feat_dim_list = []

    for data_name in ['blast_char', 'bank', 'income', 'shoppers', 'shrutime']:
        train_ds, test_ds = load_single_dataset(
            data_path=f"data_processed/{data_name}_data.csv",
            label_path=f"data_processed/{data_name}_label.csv",
            seed=seed,
            split=split,
            data_name=data_name
        )

        train_ds_list.append(train_ds)
        test_ds_list.append(test_ds)
        raw_feat_dim_list.append(train_ds.data.shape[1])
    
    return train_ds_list, test_ds_list, raw_feat_dim_list